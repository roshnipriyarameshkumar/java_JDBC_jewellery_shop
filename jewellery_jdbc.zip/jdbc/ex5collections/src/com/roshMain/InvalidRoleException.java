package com.roshMain;

class InvalidRoleException extends Exception {
    public InvalidRoleException(String message) {
        super(message);
    }
}
