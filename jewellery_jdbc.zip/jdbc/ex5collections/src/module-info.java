/**
 * 
 */
/**
 * 
 */
module ex5collections {
	requires java.desktop;
	requires java.sql;
}